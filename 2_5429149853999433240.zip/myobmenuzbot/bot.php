<?php
define('API_KEY',"821932023:AAFn8xmfe_fIjKdflwt8urgs38UGt-pWbIQ");
$admin = "652903849";

$servername = "localhost";
$username = "islomjon2727_obmen";
$password = "3060506a";
$dbname = "islomjon2727_obmen"; 

$conn = new mysqli($servername, $username, $password, $dbname);

require_once("users.php");

function put($fayl,$nima){
file_put_contents("$fayl","$nima");
}
function get($fayl){
$get = file_get_contents("$fayl");
return $get;
}
function ty($ch){ 
return bot('sendChatAction', [
'chat_id' => $ch,
'action' => 'typing',
]);
}
function editMessageText(
        $chatId,
        $messageId,
        $text,
        $parseMode = null,
        $disablePreview = false,
        $replyMarkup = null,
        $inlineMessageId = null
    ) {
       return bot('editMessageText', [
            'chat_id' => $chatId,
            'message_id' => $messageId,
            'text' => $text,
            'inline_message_id' => $inlineMessageId,
            'parse_mode' => $parseMode,
            'disable_web_page_preview' => $disablePreview,
            'reply_markup' => $replyMarkup,
        ]);
    }
function ACL($callbackQueryId, $text = null, $showAlert = false)
{
     return bot('answerCallbackQuery', [
        'callback_query_id' => $callbackQueryId,
        'text' => $text,
        'show_alert'=>$showAlert,
    ]);
}
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;

$cid = $message->chat->id;
$firstname = $message->from->first_name;
$cidtyp = $message->chat->type;
$miid = $message->message_id;
$tx = $message->text;
$call = $update->callback_query->data;
$phone_number = $message->contact->phone_number;
$mmid = $callback->inline_message_id;
$mes = $callback->message;
$mid = $mes->message_id;
$cmtx = $mes->text;
$mmid = $callback->inline_message_id;
$idd = $callback->message->chat->id;
$cbid = $callback->from->id;
$quer = $callback_query->message;
$data = $callback->data;
$ida = $callback->id;
$get = $message->from->username;
$cqid = $update->callback_query->id;
$callback_query = $update->callback_query;
$chat_id2 = $update->callback_query->message->chat->id;
$message_id = $update->callback_query->message->message_id;

$stp = file_get_contents("user/$cid.step");
mkdir("user");
$step = file_get_contents("click/$cid.step");
mkdir("click");
$banan = file_get_contents("click.ban");
$raqam = file_get_contents("numer/$cid.num");

$qiwizahira = file_get_contents("zahira/qiwi.txt");
$qiwiusdzahira = file_get_contents("zahira/qiwiusd.txt");
$xbetrubzahira = file_get_contents("zahira/xbetrub.txt");
$beelinembzahira = file_get_contents("zahira/beelinemb.txt");

$wmzzahira = file_get_contents("zahira/wmz.txt");
$wmrzahira = file_get_contents("zahira/wmr.txt");
$sberzahira = file_get_contents("zahira/sber.txt");
$uzcardzahira = file_get_contents("zahira/uzcard.txt");

if((mb_stripos($banan,$cid)!==false) and isset($update)){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"*BAN bilan tabriklayman, endi siz bandan chiqmaysiz!*",
'parse_mode'=>"markdown",
]);
}else{
$buton = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"🔄 Valyuta ayirboshlash"],],
[['text'=>"📊Kurs | 💰Zahira"],['text'=>"🔰 Hamyonlar"],],
[['text'=>"📂 Almashuvlar"],['text'=>"📓 Ma'lumotlar"],],
[['text'=>"📞 Biz bilan aloqa"],['text'=>"🕰 Ish vaqti"],],
]
]);

$profil = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"➕ UZCARD"],['text'=>"➕ WMR"],],
[['text'=>"➕ WMZ"],['text'=>"➕ QIWI RUB"],['text'=>"➕ QIWI USD"],],
[['text'=>"➕ 1xBet RUB"],['text'=>"➕ Beeline 1000 MB"],['text'=>"➕ SBERBANK RUB"],],
[['text'=>"🏠 Bosh menu"]],
]
]);

$bekor = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"🏠 Bosh menu"],],
]
]);

$but = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"Tekshirish"],],
[['text'=>"🏠 Bosh menu"],],
]
]);
if($phone_number){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"Raqam kiritildi!",
'parse_mode'=>"markdown",
'reply_markup'=>$buton,
]);
}
    /*
        else{
$raq = json_encode([
'resize_keyboard'=>true,
'one_time_keyboard' =>false,
    'reply_markup'=>json_encode(
['resize_keyboard'=>true,
'keyboard' => [
[["text"=>"Share my phone number",'request_contact' =>true],],
]
])
]);

bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"Siz raqam kiritmagansiz!",
'parse_mode'=>"markdown",
'reply_markup'=>$raq,
]);
}
*/
if($tx == "рџ—‘Avto o'chirish"){
ty($cid);
file_put_contents("coment/$cid.stp","off soat");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"*вЏІKanaldagi postni o'chirish soatini belgilang.\nвќ—пёЏFaqat postni o'chirish uchun, bot admin bo'lsa o'sha postni o'chirib tashlaydi*",
'reply_markup'=>$soat,
'parse_mode'=>"markdown",
]);
}

if(mb_stripos($tx,"/start")!==false){
ty($cid);
$baza = get("click.txt");
if(mb_stripos($baza, $cid) !== false){ 
}else{
put("click.txt", $baza+1);
}
		
	/*if(!isset($data["mode"])){ // 沫桢   񦧨힠- 讠????㦪 溥 㨠魮妩򳣮㡫 흇??易믬ᮤ流		$mode = "name"; // 𐯽󯭳 衤᦬ 歳 妩򳣨㡯졤浮쳳
	}else{
		$mode = $data["mode"];
	}
	$data["mode"] = "+ Wmrni";
			set_udata($get, $data);*/
			
$salom = "Assalomu alaykum";
$salom2 = "Siz MyObmen.uz botidasiz. Botimizdan foydalanish uchun telefon raqamini kiriting!!!";
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"$salom $firstname $salom2",
'parse_mode'=>"markdown",
'reply_to_message_id'=>$miid,
    'reply_markup'=>json_encode(
['resize_keyboard'=>true,
'keyboard' => [
[["text"=>"Telefon raqamni yuborish",'request_contact' =>true],],
]
])
]);
}
if($tx == "📓 Ma'lumotlar"){
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Foydali ma'lumotlar:

Bizning kanal:
@Myobmenuz

Bizning Sayt:
http://myobmen.uz

Dasturchi: Myobmeuz",
'reply_markup'=>$buton,
]);
}
if($tx == "📂 Almashuvlar"){
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Barchasi shu kanalda @myobmenchek",
'reply_markup'=>$buton,
]);
}
if($tx == "🔰 Hamyonlar"){
	
	$tmp = file_get_contents("user/cl$cid.txt");
	$tmpq = file_get_contents("user/qw$cid.txt");
	$tmpz = file_get_contents("user/wz$cid.txt");
	$tmpr = file_get_contents("user/wr$cid.txt");
	$tmps = file_get_contents("user/sb$cid.txt");
	$tmpw = file_get_contents("user/qusd$cid.txt");
	$tmpe = file_get_contents("user/xbet$cid.txt");
	$tmpt = file_get_contents("user/beel$cid.txt");
	if(!$tmpq){
		$tmpq = "Kiritilmagan";
		};
		if(!$tmp){
		$tmp = "Kiritilmagan";
		};
		if(!$tmpr){
		$tmpr = "Kiritilmagan";
		};
		if(!$tmpz){
		$tmpz = "Kiritilmagan";
		};
		if(!$tmpw){
		$tmpw = "Kiritilmagan";
		};
		if(!$tmpe){
		$tmpe = "Kiritilmagan";
		};
		if(!$tmpt){
		$tmpt = "Kiritilmagan";
		};
		if(!$tmps){
		$tmps = "Kiritilmagan";
		};
	bot('sendMessage',[
	'chat_id'=>$cid,
        'text'=>"🔖 *UzCard:* ```$tmp```\n🔖 *Wmr:* ```$tmpr```\n🔖 *Wmz:* ```$tmpz```\n🔖 *QIWI RUB:* ```$tmpq```\n🔖 *QIWI USD:* ```$tmpw```\n🔖 *1xBet RUB:* ```$tmpe```\n🔖 *Beeline 1000 MB:* ```$tmpt```\n🔖 *SBERBANK RUB:* ```$tmps```",
     'parse_mode'=>"markdown",
'reply_markup'=>$profil,
        ]);
	}

if($tx == "➕ UZCARD"){
		put("user/$cid.step","uzcard");
	bot('sendMessage',[
	'chat_id'=>$cid,
        'text'=>"UzCard raqamingizni kiriting.",
     
        ]);
		
	}
	if($stp == "uzcard"){
if($tx == "🏠 Bosh menu"){
}else{
$str = strlen($tx);
$str1 = strlen("8600050486838883");
if($str == $str1){
put("user/cl$cid.txt","$tx");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"*✅UzCard raqami qabul qilindi.*",
'parse_mode'=>"markdown",
'reply_markup'=>$bekor,
]);
unlink("user/$cid.step");
}
}
	}
	if($tx == "➕ WMR"){
		put("user/$cid.step","wmr");
	bot('sendMessage',[
	'chat_id'=>$cid,
        'text'=>"WMR raqamingizni kiriting.",
     
        ]);
		
	}
	if($stp == "wmr"){
if($tx == "🏠 Bosh menu"){
}else{
$str = strlen($tx);
$str1 = strlen("R177829916506");
if($str == $str1){
put("user/wr$cid.txt","$tx");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"*✅ WMR raqami qabul qilindi.*",
'parse_mode'=>"markdown",
'reply_markup'=>$bekor,
]);
unlink("user/$cid.step");
}
}
	}
	if($tx == "➕ WMZ"){
		put("user/$cid.step","wmz");
	bot('sendMessage',[
	'chat_id'=>$cid,
        'text'=>"WMZ raqamingizni kiriting.",
     
        ]);
		
	}
	if($stp == "wmz"){
if($tx == "🏠 Bosh menu"){
}else{
$str = strlen($tx);
$str1 = strlen("Z177829916506");
if($str == $str1){
put("user/wz$cid.txt","$tx");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"*✅ WMZ raqami qabul qilindi.*",
'parse_mode'=>"markdown",
'reply_markup'=>$bekor,
]);
unlink("user/$cid.step");
}
}
	}
	
	if($tx == "➕ QIWI RUB"){
		put("user/$cid.step","qiwi");
	bot('sendMessage',[
	'chat_id'=>$cid,
        'text'=>"QIWI RUB raqamingizni kiriting.",
     
        ]);
		
	}
	if($stp == "qiwi"){
if($tx == "🏠 Bosh menu"){
}else{
$str = strlen($tx);
$str1 = strlen("+998939890245");
if($str == $str1){
put("user/qw$cid.txt","$tx");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"*✅ QIWI RUB raqami qabul qilindi.*",
'parse_mode'=>"markdown",
'reply_markup'=>$bekor,
]);
unlink("user/$cid.step");
}
	}
}
		if($tx == "➕ QIWI USD"){
		put("user/$cid.step","qiwiusd");
	bot('sendMessage',[
	'chat_id'=>$cid,
        'text'=>"QIWI USD raqamingizni kiriting.",
     
        ]);
		
	}
	if($stp == "qiwiusd"){
if($tx == "🏠 Bosh menu"){
}else{
$str = strlen($tx);
$str1 = strlen("+998939890245");
if($str == $str1){
put("user/qusd$cid.txt","$tx");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"*✅ QIWI USD raqami qabul qilindi.*",
'parse_mode'=>"markdown",
'reply_markup'=>$bekor,
]);
unlink("user/$cid.step");
}
}
}
			if($tx == "➕ 1xBet RUB"){
		put("user/$cid.step","1xbet");
	bot('sendMessage',[
	'chat_id'=>$cid,
        'text'=>"1xBet RUB raqamingizni kiriting",
     
        ]);
		
	}
	if($stp == "1xbet"){
if($tx == "🏠 Bosh menu"){
}else{
$str = strlen($tx);
$str1 = strlen("23149325");
if($str == $str1){
put("user/xbet$cid.txt","$tx");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"*✅ 1xBet RUB raqami qabul qilindi.*",
'parse_mode'=>"markdown",
'reply_markup'=>$bekor,
]);
unlink("user/$cid.step");
}
	}
}
	if($tx == "➕ Beeline 1000 MB"){
		put("user/$cid.step","beeline");
	bot('sendMessage',[
	'chat_id'=>$cid,
        'text'=>"Beeline raqamingizni kiriting.\nRaqamni 901234567 korinishda kiriting.",
     
        ]);
		
	}
	if($stp == "beeline"){
if($tx == "🏠 Bosh menu"){
}else{
$str = strlen($tx);
$str1 = strlen("939890245");
if($str == $str1){
put("user/beel$cid.txt","$tx");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"*✅ Beeline raqami qabul qilindi.*",
'parse_mode'=>"markdown",
'reply_markup'=>$bekor,
]);
unlink("user/$cid.step");
}
	}
}
	
	if($tx == "➕ SBERBANK RUB"){
		put("user/$cid.step","sber");
	bot('sendMessage',[
	'chat_id'=>$cid,
        'text'=>"SBERBANK RUB raqamingizni kiriting",
     
        ]);
		
	}
	if($stp == "sber"){
if($tx == "🏠 Bosh menu"){
}else{
$str = strlen($tx);
$str1 = strlen("8600050486838883");
if($str == $str1){
put("user/sb$cid.txt","$tx");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"*✅ SBERBANK RUB raqami qabul qilindi.*",
'parse_mode'=>"markdown",
'reply_markup'=>$bekor,
]);
unlink("user/$cid.step");
}
}
	}
if($tx == "🔄 Valyuta ayirboshlash"){
	bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Valyutalarni tanlang: (🔹Berish) va (🔸Olish)",
        'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'🔹 UZCARD','callback_data'=>'uzcard'],['text'=>'🔸 UZCARD','callback_data'=>'uzcard-'],],
            [['text'=>'🔹 WMR','callback_data'=>'wmr'],['text'=>'🔸 WMR','callback_data'=>'wmr-'],],
			[['text'=>'🔹 WMZ','callback_data'=>'wmz'],['text'=>'🔸 WMZ','callback_data'=>'wmz-'],],
			[['text'=>'🔹 QIWI RUB','callback_data'=>'qiwi'],['text'=>'🔸 QIWI RUB','callback_data'=>'qiwi-'],],
			[['text'=>'🔹 QIWI USD','callback_data'=>'qiwiusd'],['text'=>'🔸 QIWI USD','callback_data'=>'qiwiusd-'],],
			[['text'=>'--','callback_data'=>'xbet'],['text'=>'🔸 1xBet RUB','callback_data'=>'xbet-'],],
			[['text'=>'--','callback_data'=>'beeline'],['text'=>'🔸 Beeline 1000 MB','callback_data'=>'beeline-'],],
			[['text'=>'🔹 SBERBANK RUB','callback_data'=>'sber'],['text'=>'🔸 SBERBANK RUB','callback_data'=>'sber-'],],
            ]
            ])
        ]);
}
if ($call == 'uzcard') {
    bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'text'=>"Valyutalarni tanlang: (🔹Berish) va (🔸Olish)",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
			[['text'=>'✅🔹 UZCARD','callback_data'=>'uzcard'],['text'=>'▫️','callback_data'=>'--'],],
			[['text'=>'🔹 WMR','callback_data'=>'wmr'],['text'=>'🔸 WMR','callback_data'=>'uzcard_wmr']],
			[['text'=>'🔹 WMZ','callback_data'=>'wmz'],['text'=>'🔸 WMZ','callback_data'=>'uzcard_wmz'],],
            [['text'=>'🔹 QIWI RUB','callback_data'=>'qiwi'],['text'=>'🔸 QIWI RUB','callback_data'=>'uzcard_qiwi'],],
			[['text'=>'🔹 QIWI USD','callback_data'=>'qiwiusd'],['text'=>'🔸 QIWI USD','callback_data'=>'uzcard_usd'],],
			[['text'=>'--','callback_data'=>'xbet'],['text'=>'🔸 1xBet RUB','callback_data'=>'uzcard_xbet'],],
			[['text'=>'--','callback_data'=>'beel'],['text'=>'🔸 Beeline 1000 MB','callback_data'=>'uzcard_beel'],],
			[['text'=>'🔹 SBERBANK RUB','callback_data'=>'sber'],['text'=>'🔸 SBERBANK RUB','callback_data'=>'sberuz'],],
            ]
            ])
        ]);
}	
if ($call == 'wmr') {
    bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'text'=>"Valyutalarni tanlang: (🔹Berish) va (🔸Olish)",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'🔹 UZCARD','callback_data'=>'uzcard'],['text'=>'🔸 UZCARD','callback_data'=>'wmr_uzcard'],],
            [['text'=>'✅🔹 WMR','callback_data'=>'wmr'],['text'=>'▫️','callback_data'=>'--']],
            [['text'=>'🔹 WMZ','callback_data'=>'wmz'],['text'=>'--','callback_data'=>'--'],],
            [['text'=>'🔹 QIWI RUB','callback_data'=>'qiwi'],['text'=>'--','callback_data'=>'--'],],
            [['text'=>'🔹 QIWI USD','callback_data'=>'qiwiusd'],['text'=>'--','callback_data'=>'--'],],
            [['text'=>'--','callback_data'=>'xbet'],['text'=>'--','callback_data'=>'--'],],
            [['text'=>'--','callback_data'=>'beel'],['text'=>'--','callback_data'=>'--'],],
			[['text'=>'🔹 SBERBANK RUB','callback_data'=>'sber'],['text'=>'--','callback_data'=>'sber'],],
            ]
            ])
        ]);
}
if ($call == 'wmz') {
    bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'text'=>"Valyutalarni tanlang: (🔹Berish) va (🔸Olish)",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'🔹 UZCARD','callback_data'=>'uzcard'],['text'=>'🔸 UZCARD','callback_data'=>'wmz_uzcard'],],
            [['text'=>'🔹 WMR','callback_data'=>'wmr'],['text'=>'--','callback_data'=>'--']],
            [['text'=>'✅🔹 WMZ','callback_data'=>'wmz'],['text'=>'▫️','callback_data'=>'--'],],
            [['text'=>'🔹 QIWI RUB','callback_data'=>'qiwi'],['text'=>'--','callback_data'=>'--'],],
            [['text'=>'🔹 QIWI USD','callback_data'=>'qiwiusd'],['text'=>'--','callback_data'=>'--'],],
            [['text'=>'--','callback_data'=>'xbet'],['text'=>'--','callback_data'=>'--'],],
            [['text'=>'--','callback_data'=>'beel'],['text'=>'--','callback_data'=>'--'],],
			[['text'=>'🔹 SBERBANK RUB','callback_data'=>'sber'],['text'=>'--','callback_data'=>'--'],],
            ]
            ])
        ]);
}
if ($call == 'qiwi') {
    bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'text'=>"Valyutalarni tanlang: (🔹Berish) va (🔸Olish)",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'🔹 UZCARD','callback_data'=>'uzcard'],['text'=>'🔸 UZCARD','callback_data'=>'qiwi_uzcard'],],
            [['text'=>'🔹 WMR','callback_data'=>'wmr'],['text'=>'--','callback_data'=>'--']],
            [['text'=>'🔹 WMZ','callback_data'=>'wmz'],['text'=>'--','callback_data'=>'--'],],
            [['text'=>'✅🔹 QIWI RUB','callback_data'=>'qiwi'],['text'=>'▫️','callback_data'=>'--'],],
            [['text'=>'🔹 QIWI USD','callback_data'=>'qiwiusd'],['text'=>'--','callback_data'=>'--'],],
            [['text'=>'--','callback_data'=>'xbet'],['text'=>'--','callback_data'=>'--'],],
            [['text'=>'--','callback_data'=>'beel'],['text'=>'--','callback_data'=>'--'],],
			[['text'=>'🔹 SBERBANK RUB','callback_data'=>'sber'],['text'=>'--','callback_data'=>'--'],],
            ]
            ])
        ]);
}
if ($call == 'qiwiusd') {
    bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'text'=>"Valyutalarni tanlang: (🔹Berish) va (🔸Olish)",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'🔹 UZCARD','callback_data'=>'uzcard'],['text'=>'🔸 UZCARD','callback_data'=>'qiwiusd_uzcard'],],
            [['text'=>'🔹 WMR','callback_data'=>'wmr'],['text'=>'--','callback_data'=>'--']],
            [['text'=>'🔹 WMZ','callback_data'=>'wmz'],['text'=>'--','callback_data'=>'--'],],
            [['text'=>'🔹 QIWI RUB','callback_data'=>'qiwi'],['text'=>'--','callback_data'=>'--'],],
            [['text'=>'✅🔹 QIWI USD','callback_data'=>'qiwiusd'],['text'=>'▫️','callback_data'=>'--'],],
            [['text'=>'--','callback_data'=>'xbet'],['text'=>'--','callback_data'=>'--'],],
            [['text'=>'--','callback_data'=>'beel'],['text'=>'--','callback_data'=>'--'],],
			[['text'=>'🔹 SBERBANK RUB','callback_data'=>'sber'],['text'=>'--','callback_data'=>'--'],],
            ]
            ])
        ]);
}
/*if ($call == 'xbet') {
    bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'text'=>"Valyutalarni tanlang: (🔹Berish) va (🔸Olish)",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'🔹 UZCARD','callback_data'=>'uzcard'],['text'=>'🔸 UZCARD','callback_data'=>'--'],],
            [['text'=>'🔹 WMR','callback_data'=>'wmr'],['text'=>'--','callback_data'=>'--']],
            [['text'=>'🔹 WMZ','callback_data'=>'wmz'],['text'=>'--','callback_data'=>'--'],],
            [['text'=>'🔹 QIWI RUB','callback_data'=>'qiwi'],['text'=>'--','callback_data'=>'--'],],
            [['text'=>'🔹 QIWI USD','callback_data'=>'qiwiusd'],['text'=>'--','callback_data'=>'--'],],
            [['text'=>'--','callback_data'=>'xbet'],['text'=>'▫️','callback_data'=>'--'],],
            [['text'=>'--','callback_data'=>'beel'],['text'=>'--','callback_data'=>'--'],],
			[['text'=>'🔹 SBERBANK RUB','callback_data'=>'sber'],['text'=>'--','callback_data'=>'--'],],
            ]
            ])
        ]);
}
if ($call == 'beel') {
    bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'text'=>"Valyutalarni tanlang: (🔹Berish) va (🔸Olish)",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'🔹 UZCARD','callback_data'=>'uzcard'],['text'=>'🔸 UZCARD','callback_data'=>'beeline_uzcard'],],
            [['text'=>'🔹 WMR','callback_data'=>'wmr'],['text'=>'--','callback_data'=>'--']],
            [['text'=>'🔹 WMZ','callback_data'=>'wmz'],['text'=>'--','callback_data'=>'--'],],
            [['text'=>'🔹 QIWI RUB','callback_data'=>'qiwi'],['text'=>'--','callback_data'=>'--'],],
            [['text'=>'🔹 QIWI USD','callback_data'=>'qiwiusd'],['text'=>'--','callback_data'=>'--'],],
            [['text'=>'--','callback_data'=>'xbet'],['text'=>'--','callback_data'=>'--'],],
            [['text'=>'--','callback_data'=>'beel'],['text'=>'▫️','callback_data'=>'--'],],
			[['text'=>'🔹 SBERBANK RUB','callback_data'=>'sber'],['text'=>'--','callback_data'=>'--'],],
            ]
            ])
        ]);
}*/
if ($call == 'sber') {
    bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'text'=>"Valyutalarni tanlang: (🔹Berish) va (🔸Olish)",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'🔹 UZCARD','callback_data'=>'uzcard'],['text'=>'🔸 UZCARD','callback_data'=>'sberuz'],],
            [['text'=>'🔹 WMR','callback_data'=>'wmr'],['text'=>'--','callback_data'=>'--']],
            [['text'=>'🔹 WMZ','callback_data'=>'wmz'],['text'=>'--','callback_data'=>'--'],],
            [['text'=>'🔹 QIWI RUB','callback_data'=>'qiwi'],['text'=>'--','callback_data'=>'--'],],
            [['text'=>'🔹 QIWI USD','callback_data'=>'qiwiusd'],['text'=>'--','callback_data'=>'--'],],
            [['text'=>'--','callback_data'=>'xbet'],['text'=>'--','callback_data'=>'--'],],
            [['text'=>'--','callback_data'=>'beel'],['text'=>'--','callback_data'=>'--'],],
			[['text'=>'✅🔹 SBERBANK RUB','callback_data'=>'sber'],['text'=>'▫️','callback_data'=>'--'],],
            ]
            ])
        ]);
}
if ($call == 'wmr_uzcard') {
	$baza = get("click.txt");
if(mb_stripos($baza, $cid) !== false){ 
}else{
	
put("click.txt", $baza+1);
}
$baz = $baza+1;
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
	if($tmp and $tmpr){
    bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Almashinuv*
		Id: `$baz`
		Berish: *WMR*
		Olish: *UZCARD*
		WMR raqam: *R$tmpr*
		UZCARD raqam: *$tmp*
		",
		'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'Berishni kiritish * WMR','callback_data'=>'1'],],
			[['text'=>'Olishni kiritsh * UZCARD','callback_data'=>'2'],],
            ]
            ])
        ]);
		
	}else{
	 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"Siz hamyonlarni kiritmagansiz",
        ]);
}
}
if ($call == '1') {
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"
*Berish miqdorini* WMRda kiriting:
		
*Minimal* `150 WMR`
*Maksimal* `$wmrzahira` WMR
		",
		 ]);
		 put("click/$chat_id2.step","changewmr");
		 
}
if ($call == '2') {
put("click/$chat_id2.step","changewmr2");
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
	$miqdor = ($wmrzahira * 122);
 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"
*Olish miqdorini* UZCARD da kiriting

*Minimum* `20000` UZS
*Maksimum* `$miqdor` UZS
		",
		 ]);
		 
}
	
if ($call == 'uzcard_wmr') {
	$baza = get("click.txt");
if(mb_stripos($baza, $cid) !== false){ 
}else{
	
put("click.txt", $baza+1);
}
$baz = $baza+1;
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
	if($tmp and $tmpr){
    bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Almashinuv*
		Id: `$baz`
		Berish: *UZCARD*
	    Olish: *WMR*
		WMR : *R$tmpr*
		CLICK : *$tmp*
		
	
		",
		'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'Berishni kiritish * UZCARD','callback_data'=>'3'],],
			[['text'=>'Olishni kiritsh * WMR','callback_data'=>'4'],],
            ]
            ])
        ]);
	}else{
	 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"Siz hamyonlarni kiritmagansiz",
        ]);
}
}
if ($call == '3') {
put("click/$chat_id2.step","changeclickwmr");
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
	$miqdor = ($wmrzahira * 140);
 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Berish miqdorini* UZCARD da kiriting
*Minimium:* `20000` UZS
*Maksimum:*	`$miqdor` UZS	
		",
		 ]);
		 
}
if ($call == '4') {
put("click/$chat_id2.step","changeclickwmr1");
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Olish miqdorini * WMR da kiriting
*Minimium:* `150` WMR
*Maksimum:*	`$wmrzahira` WMR	
		",
		 ]);
		 
}
if ($call == 'sberuz') {
	$baza = get("click.txt");
if(mb_stripos($baza, $cid) !== false){ 
}else{
	
put("click.txt", $baza+1);
$baz = $baza+1;
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmps = file_get_contents("user/sb$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
	if($tmp and $tmpr){
    bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Almashinuv*
		Id: `$baz`
		Berish: *UZCARD*
		Olish: *SBERBANK RUB*
		SBERBANK RUB: *$tmps*
		UZCARD: *$tmp*
		
	
		",
		'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'Berishni kiritish * UZCARD','callback_data'=>'uzsb'],],
			[['text'=>'Olishni kiritsh * SBERBANK RUB','callback_data'=>'sbuz'],],
            ]
            ])
        ]);
	}else{
	 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"Siz hamyonlarni kiritmagansiz",
        ]);
}
}
}

if ($call == 'uzsb') {
put("click/$chat_id2.step","changeclicksber");
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
	$miqdor = ($sberzahira * 140);
 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Berish miqdorini * UZCARD da kiriting
*Minimium:* `20000` UZS
*Maksimum:* `$miqdor` RUB
		",
		 ]);
		 
}
if ($call == 'sbuz') {
put("click/$chat_id2.step","changeclicksber1");
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Olish miqdorini* SBERBANK RUB da kiriting
*Minimium:* `150` RUB	
*Maksimum:* `$sberzahira` RUB	
		",
		 ]);
		 
}
if ($call == 'uzcard_wmz') {
	$baza = get("click.txt");
if(mb_stripos($baza, $cid) !== false){ 
}else{
	
put("click.txt", $baza+1);
}
$baz = $baza+1;
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
	if($tmp and $tmpz){
    bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Almashinuv*
		Id: `$baz`
		Berish: *UZCARD*
		Olish: *WMZ*
		WMZ: *$tmpz*
		UZCARD: *$tmp*
		
			
	",
	'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'Berishni kiritish * UZCARD','callback_data'=>'9'],],
			[['text'=>'Olishni kiritsh * WMZ','callback_data'=>'10'],],
            ]
            ])
        ]);
		
	}else{
	 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"Siz hamyonlarni kiritmagansiz",
        ]);
}
}

if ($call == '9') {
put("click/$chat_id2.step","changeclickwmz");
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
	$miqdor = ($wmzzahira * 9000);
 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Berish miqdorini* UZCARD da kiriting
*Minimium:* `20000` UZS
*Maksimum:* `$miqdor` UZS
		",
		 ]);
		 
}
if ($call == '10') {
put("click/$chat_id2.step","changeclickwmz1");
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Olish miqdorini* WMZ da kiriting
*Minimium:* `2` WMZ	
*Maksimum:* `$wmzzahira` WMZ	
		",
		 ]);
		 
}
if ($call == 'uzcard_qiwi') {
	$baza = get("click.txt");
if(mb_stripos($baza, $cid) !== false){ 
}else{
	
put("click.txt", $baza+1);
}
$baz = $baza+1;
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
	if($tmp and $tmpq){
    bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Almashinuv*
		Id: `$baz`
		Berish: *UZCARD*
		Olish: *QIWI*
		QIWI: *$tmpq*
		UZCARD: *$tmp*
		
		
	",
	'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'Berishni kiritish * UZCARD','callback_data'=>'11'],],
			[['text'=>'Olishni kiritsh * QIWI','callback_data'=>'12'],],
            ]
            ])
        ]);
		put("click/$chat_id2.step","changeclickqiwi");
	}else{
	 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"Siz hamyonlarni kiritmagansiz",
        ]);
}
}
if ($call == 'uzcard_usd') {
	$baza = get("click.txt");
if(mb_stripos($baza, $cid) !== false){ 
}else{
	
put("click.txt", $baza+1);
}
$baz = $baza+1;
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
	if($tmp and $tmpq){
    bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Almashinuv*
		Id: `$baz`
		Berish: *UZCARD*
		Olish: *QIWI USD*
		QIWI USD: *$tmpq*
		UZCARD: *$tmp*
		
		
	",
	'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'Berishni kiritish * UZCARD','callback_data'=>'25'],],
			[['text'=>'Olishni kiritsh * QIWI USD','callback_data'=>'26'],],
            ]
            ])
        ]);
		put("click/$chat_id2.step","changeclickusd");
	}else{
	 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"Siz hamyonlarni kiritmagansiz",
        ]);
}
}
if ($call == 'uzcard_xbet') {
	$baza = get("click.txt");
if(mb_stripos($baza, $cid) !== false){ 
}else{
	
put("click.txt", $baza+1);
}
$baz = $baza+1;
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
	if($tmp and $tmpq){
    bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Almashinuv*
		Id: `$baz`
		Berish: *UZCARD*
		Olish: *1xBet RUB*
		1xBet RUB: *$tmpe*
		UZCARD: *$tmp*
		
		
	",
	'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'Berishni kiritish * UZCARD','callback_data'=>'28'],],
            [['text'=>'Olishni kiritish * 1xBet RUB','callback_data'=>'27'],],
            ]
            ])
        ]);
		put("click/$chat_id2.step","changeclickxbet");
	}else{
	 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"Siz hamyonlarni kiritmagansiz",
        ]);
}
}
if ($call == 'uzcard_beel') {
	$baza = get("click.txt");
if(mb_stripos($baza, $cid) !== false){ 
}else{
	
put("click.txt", $baza+1);
}
$baz = $baza+1;
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
	if($tmp and $tmpq){
    bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Almashinuv*
		Id: `$baz`
		Berish: *UZCARD*
		Olish: *Beeline MB*
		Beeline MB: *$tmpt*
		UZCARD: *$tmp*
		
		
	",
	'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'Berishni kiritish * UZCARD','callback_data'=>'29'],],
            ]
            ])
        ]);
		put("click/$chat_id2.step","changeclickbeel");
	}else{
	 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"Siz hamyonlarni kiritmagansiz",
        ]);
}
}
if ($call == '11') {
put("click/$chat_id2.step","changeclickqiwi");
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
	$miqdor = ($qiwizahira * 140);
 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Berish miqdorini* UZCARD da kiriting
*Minimium:* `20000` UZS
*Maksimum:* `$miqdor` UZS
		",
		 ]);
		 
}
if ($call == '12') {
put("click/$chat_id2.step","changeclickqiwi1");
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Olish miqdorini* QIWI da kiriting
*Minimium:* `150` QIWI
*Maksimum:* `$qiwizahira` QIWI
		",
		 ]);
		 
}
if ($call == 'qiwi_uzcard') {
	$baza = get("click.txt");
if(mb_stripos($baza, $cid) !== false){ 
}else{
	
put("click.txt", $baza+1);
}
$baz = $baza+1;
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
	if($tmp and $tmpq){
    bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Almashinuv*
		Id: `$baz`
		Berish: *QIWI*
		Olish: *UZCARD*
		QIWI: *$tmpq*
		UZCARD: *$tmp*
		
	",
	'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'Berishni kiritish * Qiwi','callback_data'=>'15'],],
			[['text'=>'Olishni kiritsh * UZCARD','callback_data'=>'16'],],
            ]
            ])
        ]);
		put("click/$chat_id2.step","changeqiwiclick");
	}else{
	 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"Siz hamyonlarni kiritmagansiz",
        ]);
}
}
if ($call == 'xbet_uzcard') {
	$baza = get("click.txt");
if(mb_stripos($baza, $cid) !== false){ 
}else{
	
put("click.txt", $baza+1);
}
$baz = $baza+1;
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
	if($tmp and $tmpe){
    bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Almashinuv*
		Id: `$baz`
		Berish: *1xBet RUB*
		Olish: *UZCARD*
		1xBet RUB: *$tmpe*
		UZCARD: *$tmp*
		
	",
	'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'Berishni kiritish * 1xBet RUB','callback_data'=>'33'],],
			[['text'=>'Olishni kiritsh * UZCARD','callback_data'=>'34'],],
            ]
            ])
        ]);
		put("click/$chat_id2.step","changexbetclick");
	}else{
	 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"Siz hamyonlarni kiritmagansiz",
        ]);
}
}
if ($call == 'beeline_uzcard') {
	$baza = get("click.txt");
if(mb_stripos($baza, $cid) !== false){ 
}else{
	
put("click.txt", $baza+1);
}
$baz = $baza+1;
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
	if($tmp and $tmpt){
    bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Almashinuv*
		Id: `$baz`
		Berish: *Beeline MB*
		Olish: *UZCARD*
		Beeline MB: *$tmpt*
		UZCARD: *$tmp*
		
	",
	'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'Berishni kiritish * Beeline MB','callback_data'=>'35'],],
			[['text'=>'Olishni kiritsh * UZCARD','callback_data'=>'36'],],
            ]
            ])
        ]);
		put("click/$chat_id2.step","changebeelclick");
	}else{
	 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"Siz hamyonlarni kiritmagansiz",
        ]);
}
}
if ($call == '15') {
put("click/$chat_id2.step","changeqiwiclick");
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
	$miqdor = ($uzcardzahira / 128);
 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Berish miqdorini* QIWI da kiriting
*Minimium:* `150` QIWI
*Maksimum:* `$miqdor` QIWI",
		 ]);
		 
}
if ($call == '16') {
put("click/$chat_id2.step","changeqiwiclick1");
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	
 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Olish miqdorini* UZCARD da kiriting
*Minimium:* `20000` UZS
*Maksimum:* `$uzcardzahira` UZS",
		 ]);
		 
}
if ($call == 'wmz_uzcard') {
	$baza = get("click.txt");
if(mb_stripos($baza, $cid) !== false){ 
}else{
	
put("click.txt", $baza+1);
}
$baz = $baza+1;
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
	if($tmp and $tmpz){
    bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Almashinuv*
		Id: `$baz`
		Berish: *WMZ*
		Olish: *UZCARD*
		UZCARD: *$tmp*
		WMZ: *$tmpz*
		
		
	",
	'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'Berishni kiritish * WMZ','callback_data'=>'23'],],
			[['text'=>'Olishni kiritsh * UZCARD','callback_data'=>'24'],],
            ]
            ])
        ]);
	}else{
	 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"Siz hamyonlarni kiritmagansiz",
        ]);
}
}
if ($call == 'qiwiusd_uzcard') {
	$baza = get("click.txt");
if(mb_stripos($baza, $cid) !== false){ 
}else{
	
put("click.txt", $baza+1);
}
$baz = $baza+1;
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
	if($tmp and $tmpw){
    bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Almashinuv*
		Id: `$baz`
		Berish: *QIWI USD*
		Olish: *UZCARD*
		UZCARD: *$tmp*
		QIWI USD: *$tmpe*
		
		
	",
	'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'Berishni kiritish * QIWI USD','callback_data'=>'31'],],
			[['text'=>'Olishni kiritsh * UZCARD','callback_data'=>'32'],],
            ]
            ])
        ]);
	}else{
	 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"Siz hamyonlarni kiritmagansiz",
        ]);
}
}
if ($call == '23') {
put("click/$chat_id2.step","changewmzuzcard");
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
	$miqdor = ($uzcardzahira / 8400);
 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Berish miqdorini* WMZ da kiriting
*Minimium:* `2` WMZ
*Maksimum:* `$miqdor` WMZ
		",
		 ]);
		 
}
if ($call == '24') {
put("click/$chat_id2.step","changewmzuzcard1");
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Olish miqdorini* UZCARD da kiriting
*Minimium:* `20000` UZS
*Maksimum:* `$uzcardzahira` UZS
		",
		 ]);
		 
}
if ($call == '25') {
put("click/$chat_id2.step","changeqiwiusdclick1");
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
	$miqdor = ($uzcardzahira / 8200);
 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Berish miqdorini* UZCARD da kiriting
*Minimium:* `20000` UZS
*Maksimum:* `$miqdor` UZS
		",
		 ]);
		 
}
if ($call == '26') {
put("click/$chat_id2.step","changeqiwiusdclick");
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qusd$chat_id2.txt");
 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Olish miqdorini* QIWI USD da kiriting
*Minimium:* `2` QIWI USD
*Maksimum:* `$qiwiusdzahira` QIWI USD
		",
		 ]);
		 
}
if ($call == '28') {
put("click/$chat_id2.step","changexbetclick");
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Berish miqdorini* 1xBet RUB da kiriting
*Minimium:* `150` 1xBet RUB
*Maksimum:* `$xbetrubzahira` 1xBet RUB",
		 ]);
		 
}
if ($call == '27') {
put("click/$chat_id2.step","changexbetclick1");
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	
 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Olish miqdorini* UZCARD da kiriting
*Minimium:* `20000` UZS
*Maksimum:* `$uzcardzahira` UZS",
		 ]);
		 
}
if ($call == '30') {
put("click/$chat_id2.step","changebeelclick");
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Olish miqdorini* Beeline MB da kiriting
*Minimium:* `1000` Beeline MB
*Maksimum:* `$beelinembzahira` Beeline MB",
		 ]);
		 
}
if ($call == '29') {
put("click/$chat_id2.step","changebeelclick1");
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	
 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Berish miqdorini* UZCARD da kiriting
*Minimium:* `20000` UZS
*Maksimum:* `$uzcardzahira` UZS",
		 ]);
		 
}
if ($call == '31') {
put("click/$chat_id2.step","changeqiwiusduzcard");
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Berish miqdorini* QIWI USD da kiriting
*Minimium:* `2` QIWI USD
*Maksimum:* `$qiwiusdzahira` QIWI USD
		",
		 ]);
		 
}
if ($call == '32') {
put("click/$chat_id2.step","changeqiwiusduzcard1");
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Olish miqdorini* UZCARD da kiriting
*Minimium:* `20000` UZS
*Maksimum:* `$uzcardzahira` UZS
		",
		 ]);
		 
}
if ($call == '34') {
put("click/$chat_id2.step","changexbetclick1");
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	
 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Olish miqdorini* UZCARD da kiriting
*Minimium:* `20000` UZS
*Maksimum:* `$uzcardzahira` UZS",
		 ]);
		 
}
if ($call == '33') {
put("click/$chat_id2.step","changexbetclick");
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Berish miqdorini* 1xBet RUB da kiriting
*Minimium:* `150` 1xBet RUB
*Maksimum:* `$xbetrubzahira` 1xBet RUB",
		 ]);
		 
}
if ($call == '36') {
put("click/$chat_id2.step","changebeelclick1");
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	
 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Olish miqdorini* UZCARD da kiriting
*Minimium:* `20000` UZS
*Maksimum:* `$uzcardzahira` UZS",
		 ]);
		 
}
if ($call == '35') {
put("click/$chat_id2.step","changebeelclick");
$tmp = file_get_contents("user/cl$chat_id2.txt");
	$tmpq = file_get_contents("user/qw$chat_id2.txt");
	$tmpz = file_get_contents("user/wz$chat_id2.txt");
	$tmpr = file_get_contents("user/wr$chat_id2.txt");
	$tmpw = file_get_contents("user/qusd$chat_id2.txt");
	$tmpe = file_get_contents("user/xbet$chat_id2.txt");
	$tmpt = file_get_contents("user/beel$chat_id2.txt");
 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Berish miqdorini* Beeline MB da kiriting
*Minimium:* `1000` Beeline MB
*Maksimum:* `$beelinembzahira` Beeline MB",
		 ]);
		 
}
if($call == "toladim1"){
$get = file_get_contents("click/$chat_id2.tmp");
$get2 = file_get_contents("click/$chat_id2.tmp2");
$tmp1 = file_get_contents("click/$chat_id2.tmp3");
$tmp2 = file_get_contents("click/$chat_id2.tmp4");
$miqdor = file_get_contents("click/$chat_id2.miq");
$tmp3 = file_get_contents("user/wr$chat_id2.txt");
$tmp4 = file_get_contents("user/cl$chat_id2.txt");
$tmpq = file_get_contents("user/qw$chat_id2.txt");
$tmpz = file_get_contents("user/wz$chat_id2.txt");
$tmpw = file_get_contents("user/qusd$chat_id2.txt");
$tmpe = file_get_contents("user/xbet$chat_id2.txt");
$tmpt = file_get_contents("user/beel$chat_id2.txt");
if($get and $get2){
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"Almashinuv:
➖➖➖➖➖➖➖➖➖➖➖➖
*$tmp2* berib *$tmp1* olmoqchi
➖➖➖➖➖➖➖➖➖➖➖➖
*Miqdori:* `$get2`
*Miqdori:* `$miqdor`
➖➖➖➖➖➖➖➖➖➖➖➖
*UZCARD raqami*: `$tmp4`
*QIWIRUB raqami:* `$tmpq`
➖➖➖➖➖➖➖➖➖➖➖➖
/ok\_$chat_id2\_$get\_$tmp1\_$tmp2\_$miqdor
/no\_$chat_id2\_$get
➖➖➖➖➖➖➖➖➖➖➖➖
/ban\_$chat_id2\_$get",
'parse_mode'=>"markdown",
]);
unlink("click/$chat_id2.tmp");
unlink("click/$chat_id2.tmp2");
bot('sendMessage',[
'chat_id'=>$chat_id2,
'text'=>"Sizning almashuvingiz tekshiruvga yuborildi. Iltimos xabarni kuting",
'parse_mode'=>"markdown",
]);
}else{}
}
if($call == "toladim2"){
$get = file_get_contents("click/$chat_id2.tmp");
$get2 = file_get_contents("click/$chat_id2.tmp2");
$tmp1 = file_get_contents("click/$chat_id2.tmp3");
$tmp2 = file_get_contents("click/$chat_id2.tmp4");
$miqdor = file_get_contents("click/$chat_id2.miq");
$tmp3 = file_get_contents("user/wr$chat_id2.txt");
$tmp4 = file_get_contents("user/cl$chat_id2.txt");
$tmpq = file_get_contents("user/qw$chat_id2.txt");
$tmpz = file_get_contents("user/wz$chat_id2.txt");
$tmpw = file_get_contents("user/qusd$chat_id2.txt");
$tmpe = file_get_contents("user/xbet$chat_id2.txt");
$tmpt = file_get_contents("user/beel$chat_id2.txt");
if($get and $get2){
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"Almashinuv:
➖➖➖➖➖➖➖➖➖➖➖➖
*$tmp2* berib *$tmp1* olmoqchi
➖➖➖➖➖➖➖➖➖➖➖➖
*Miqdori:* `$get2`
*Miqdori:* `$miqdor`
➖➖➖➖➖➖➖➖➖➖➖➖
*UZCARD raqami*: `$tmp4`
*WMR raqami:* `$tmp3`
➖➖➖➖➖➖➖➖➖➖➖➖
/ok\_$chat_id2\_$get\_$tmp1\_$tmp2\_$miqdor
/no\_$chat_id2\_$get
➖➖➖➖➖➖➖➖➖➖➖➖
/ban\_$chat_id2\_$get",
'parse_mode'=>"markdown",
]);
unlink("click/$chat_id2.tmp");
unlink("click/$chat_id2.tmp2");
bot('sendMessage',[
'chat_id'=>$chat_id2,
'text'=>"Sizning almashuvingiz tekshiruvga yuborildi. Iltimos xabarni kuting",
'parse_mode'=>"markdown",
]);
}else{}
}
if($call == "toladim3"){
$get = file_get_contents("click/$chat_id2.tmp");
$get2 = file_get_contents("click/$chat_id2.tmp2");
$tmp1 = file_get_contents("click/$chat_id2.tmp3");
$tmp2 = file_get_contents("click/$chat_id2.tmp4");
$miqdor = file_get_contents("click/$chat_id2.miq");
$tmp3 = file_get_contents("user/wr$chat_id2.txt");
$tmp4 = file_get_contents("user/cl$chat_id2.txt");
$tmpq = file_get_contents("user/qw$chat_id2.txt");
$tmpz = file_get_contents("user/wz$chat_id2.txt");
$tmpw = file_get_contents("user/qusd$chat_id2.txt");
$tmpe = file_get_contents("user/xbet$chat_id2.txt");
$tmpt = file_get_contents("user/beel$chat_id2.txt");
if($get and $get2){
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"Almashinuv:
➖➖➖➖➖➖➖➖➖➖➖➖
*$tmp2* berib *$tmp1* olmoqchi
➖➖➖➖➖➖➖➖➖➖➖➖
*Miqdori:* `$get2`
*Miqdori:* `$miqdor`
➖➖➖➖➖➖➖➖➖➖➖➖
*UZCARD raqami*: `$tmp4`
*QIWI USD raqami*: `$tmpw`
➖➖➖➖➖➖➖➖➖➖➖➖
/ok\_$chat_id2\_$get\_$tmp1\_$tmp2\_$miqdor
/no\_$chat_id2\_$get
➖➖➖➖➖➖➖➖➖➖➖➖
/ban\_$chat_id2\_$get",
'parse_mode'=>"markdown",
]);
unlink("click/$chat_id2.tmp");
unlink("click/$chat_id2.tmp2");
bot('sendMessage',[
'chat_id'=>$chat_id2,
'text'=>"Sizning almashuvingiz tekshiruvga yuborildi. Iltimos xabarni kuting",
'parse_mode'=>"markdown",
]);
}else{}
}
if($call == "toladim4"){
$get = file_get_contents("click/$chat_id2.tmp");
$get2 = file_get_contents("click/$chat_id2.tmp2");
$tmp1 = file_get_contents("click/$chat_id2.tmp3");
$tmp2 = file_get_contents("click/$chat_id2.tmp4");
$miqdor = file_get_contents("click/$chat_id2.miq");
$tmp3 = file_get_contents("user/wr$chat_id2.txt");
$tmp4 = file_get_contents("user/cl$chat_id2.txt");
$tmpq = file_get_contents("user/qw$chat_id2.txt");
$tmpz = file_get_contents("user/wz$chat_id2.txt");
$tmpw = file_get_contents("user/qusd$chat_id2.txt");
$tmpe = file_get_contents("user/xbet$chat_id2.txt");
$tmpt = file_get_contents("user/beel$chat_id2.txt");
if($get and $get2){
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"Almashinuv:
➖➖➖➖➖➖➖➖➖➖➖➖
*$tmp2* berib *$tmp1* olmoqchi
➖➖➖➖➖➖➖➖➖➖➖➖
*Miqdori:* `$get2`
*Miqdori:* `$miqdor`
➖➖➖➖➖➖➖➖➖➖➖➖
*UZCARD raqami*: `$tmp4`
*1XBETRUB raqami*: `$tmpe`
➖➖➖➖➖➖➖➖➖➖➖➖
/ok\_$chat_id2\_$get\_$tmp1\_$tmp2\_$miqdor
/no\_$chat_id2\_$get
➖➖➖➖➖➖➖➖➖➖➖➖
/ban\_$chat_id2\_$get",
'parse_mode'=>"markdown",
]);
unlink("click/$chat_id2.tmp");
unlink("click/$chat_id2.tmp2");
bot('sendMessage',[
'chat_id'=>$chat_id2,
'text'=>"Sizning almashuvingiz tekshiruvga yuborildi. Iltimos xabarni kuting",
'parse_mode'=>"markdown",
]);
}else{}
}
if($call == "toladim5"){
$get = file_get_contents("click/$chat_id2.tmp");
$get2 = file_get_contents("click/$chat_id2.tmp2");
$tmp1 = file_get_contents("click/$chat_id2.tmp3");
$tmp2 = file_get_contents("click/$chat_id2.tmp4");
$miqdor = file_get_contents("click/$chat_id2.miq");
$tmp3 = file_get_contents("user/wr$chat_id2.txt");
$tmp4 = file_get_contents("user/cl$chat_id2.txt");
$tmpq = file_get_contents("user/qw$chat_id2.txt");
$tmpz = file_get_contents("user/wz$chat_id2.txt");
$tmpw = file_get_contents("user/qusd$chat_id2.txt");
$tmpe = file_get_contents("user/xbet$chat_id2.txt");
$tmpt = file_get_contents("user/beel$chat_id2.txt");
if($get and $get2){
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"Almashinuv:
➖➖➖➖➖➖➖➖➖➖➖➖
*$tmp2* berib *$tmp1* olmoqchi
➖➖➖➖➖➖➖➖➖➖➖➖
*Miqdori:* `$get2`
*Miqdori:* `$miqdor`
➖➖➖➖➖➖➖➖➖➖➖➖
*UZCARD raqami*: `$tmp4`
*BEELINEMB raqami*: `$tmpt`
➖➖➖➖➖➖➖➖➖➖➖➖
/ok\_$chat_id2\_$get\_$tmp1\_$tmp2\_$miqdor
/no\_$chat_id2\_$get
➖➖➖➖➖➖➖➖➖➖➖➖
/ban\_$chat_id2\_$get",
'parse_mode'=>"markdown",
]);
unlink("click/$chat_id2.tmp");
unlink("click/$chat_id2.tmp2");
bot('sendMessage',[
'chat_id'=>$chat_id2,
'text'=>"Sizning almashuvingiz tekshiruvga yuborildi. Iltimos xabarni kuting",
'parse_mode'=>"markdown",
]);
}else{}
}
if($call == "toladim6"){
$get = file_get_contents("click/$chat_id2.tmp");
$get2 = file_get_contents("click/$chat_id2.tmp2");
$tmp1 = file_get_contents("click/$chat_id2.tmp3");
$tmp2 = file_get_contents("click/$chat_id2.tmp4");
$miqdor = file_get_contents("click/$chat_id2.miq");
$tmp3 = file_get_contents("user/wr$chat_id2.txt");
$tmp4 = file_get_contents("user/cl$chat_id2.txt");
$tmpq = file_get_contents("user/qw$chat_id2.txt");
$tmpz = file_get_contents("user/wz$chat_id2.txt");
$tmpw = file_get_contents("user/qusd$chat_id2.txt");
$tmpe = file_get_contents("user/xbet$chat_id2.txt");
$tmpt = file_get_contents("user/beel$chat_id2.txt");
if($get and $get2){
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"Almashinuv:
➖➖➖➖➖➖➖➖➖➖➖➖
*$tmp2* berib *$tmp1* olmoqchi
➖➖➖➖➖➖➖➖➖➖➖➖
*Miqdori:* `$get2`
*Miqdori:* `$miqdor`
➖➖➖➖➖➖➖➖➖➖➖➖
*UZCARD raqami*: `$tmp4`
*WMZ raqami:* `$tmpz`
➖➖➖➖➖➖➖➖➖➖➖➖
/ok\_$chat_id2\_$get\_$tmp1\_$tmp2\_$miqdor
/no\_$chat_id2\_$get
➖➖➖➖➖➖➖➖➖➖➖➖
/ban\_$chat_id2\_$get",
'parse_mode'=>"markdown",
]);
unlink("click/$chat_id2.tmp");
unlink("click/$chat_id2.tmp2");
bot('sendMessage',[
'chat_id'=>$chat_id2,
'text'=>"Sizning almashuvingiz tekshiruvga yuborildi. Iltimos xabarni kuting",
'parse_mode'=>"markdown",
]);
}else{}
}
if($call == "toladim7"){
$get = file_get_contents("click/$chat_id2.tmp");
$get2 = file_get_contents("click/$chat_id2.tmp2");
$tmp1 = file_get_contents("click/$chat_id2.tmp3");
$tmp2 = file_get_contents("click/$chat_id2.tmp4");
$miqdor = file_get_contents("click/$chat_id2.miq");
$tmp3 = file_get_contents("user/wr$chat_id2.txt");
$tmp4 = file_get_contents("user/cl$chat_id2.txt");
$tmpq = file_get_contents("user/qw$chat_id2.txt");
$tmps = file_get_contents("user/sb$chat_id2.txt");
$tmpz = file_get_contents("user/wz$chat_id2.txt");
$tmpw = file_get_contents("user/qusd$chat_id2.txt");
$tmpe = file_get_contents("user/xbet$chat_id2.txt");
$tmpt = file_get_contents("user/beel$chat_id2.txt");
if($get and $get2){
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"Almashinuv:
➖➖➖➖➖➖➖➖➖➖➖➖
*$tmp2* berib *$tmp1* olmoqchi
➖➖➖➖➖➖➖➖➖➖➖➖
*Miqdori:* `$get2`
*Miqdori:* `$miqdor`
➖➖➖➖➖➖➖➖➖➖➖➖
*UZCARD raqami*: `$tmp4`
*WMZ raqami*: `$tmpz`
➖➖➖➖➖➖➖➖➖➖➖➖
/ok\_$chat_id2\_$get\_$tmp1\_$tmp2\_$miqdor
/no\_$chat_id2\_$get
➖➖➖➖➖➖➖➖➖➖➖➖
/ban\_$chat_id2\_$get",
'parse_mode'=>"markdown",
]);
unlink("click/$chat_id2.tmp");
unlink("click/$chat_id2.tmp2");
bot('sendMessage',[
'chat_id'=>$chat_id2,
'text'=>"Sizning almashuvingiz tekshiruvga yuborildi. Iltimos xabarni kuting",
'parse_mode'=>"markdown",
]);
}else{}
}
if($call == "toladim8"){
$get = file_get_contents("click/$chat_id2.tmp");
$get2 = file_get_contents("click/$chat_id2.tmp2");
$tmp1 = file_get_contents("click/$chat_id2.tmp3");
$tmp2 = file_get_contents("click/$chat_id2.tmp4");
$miqdor = file_get_contents("click/$chat_id2.miq");
$tmp3 = file_get_contents("user/wr$chat_id2.txt");
$tmp4 = file_get_contents("user/cl$chat_id2.txt");
$tmpq = file_get_contents("user/qw$chat_id2.txt");
$tmps = file_get_contents("user/sb$chat_id2.txt");
$tmpz = file_get_contents("user/wz$chat_id2.txt");
$tmpw = file_get_contents("user/qusd$chat_id2.txt");
$tmpe = file_get_contents("user/xbet$chat_id2.txt");
$tmpt = file_get_contents("user/beel$chat_id2.txt");
if($get and $get2){
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"Almashinuv:
➖➖➖➖➖➖➖➖➖➖➖➖
*$tmp2* berib *$tmp1* olmoqchi
➖➖➖➖➖➖➖➖➖➖➖➖
*Miqdori:* `$get2`
*Miqdori:* `$miqdor`
➖➖➖➖➖➖➖➖➖➖➖➖
*UZCARD raqami*: `$tmp4`
*SBERBANKRUB raqami*: `$tmps`
➖➖➖➖➖➖➖➖➖➖➖➖
/ok\_$chat_id2\_$get\_$tmp1\_$tmp2\_$miqdor
/no\_$chat_id2\_$get
➖➖➖➖➖➖➖➖➖➖➖➖
/ban\_$chat_id2\_$get",
'parse_mode'=>"markdown",
]);
unlink("click/$chat_id2.tmp");
unlink("click/$chat_id2.tmp2");
bot('sendMessage',[
'chat_id'=>$chat_id2,
'text'=>"Sizning almashuvingiz tekshiruvga yuborildi. Iltimos xabarni kuting",
'parse_mode'=>"markdown",
]);
}else{}
}

if($step == "changewmr"){
	if($tx > 149){
		$ru = ($tx * 122);
$qu = ($tx * 128);
$zu = ($tx * 8400);
$ur = ($tx / 140);
$uq = ($tx / 140);
$uz = ($tx / 9000);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$ru");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","UZCARD");
put("click/$cid.tmp4","WMR");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp WMR evaziga $ru UZS olasiz.

```R960899711592```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu +998943060506 karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $tmp WMR

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim2'],],
            ]
            ])
]);
unlink("click/$cid.step");
}
}
if($step == "changewmr2"){
	if($tx > 14999){
$ru = ($tx * 122);
$qu = ($tx * 128);
$zu = ($tx * 8400);
$ur = ($tx / 122);
$uq = ($tx / 140);
$uz = ($tx / 9000);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$ur");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","UZCARD");
put("click/$cid.tmp4","WMR");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp UZS evaziga $ur WMR olasiz.

```R960899711592```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu R960899711592 karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $tmp UZS

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
 'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim2'],],
            ]
            ])
]);
unlink("click/$cid.step");
}
}
if($step == "changeqiwiusdclick"){
	if($tx > 1){
		$ru = ($tx * 122);
$qu = ($tx * 128);
$zu = ($tx * 8200);
$ur = ($tx / 140);
$uq = ($tx / 140);
$uz = ($tx * 9000);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$uz");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","UZCARD");
put("click/$cid.tmp4","QIWIUSD");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp QIWI USD evaziga $uz UZS olasiz.

```+998943060506```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu +998943060506 karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $tmp QIWI USD

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim3'],],
            ]
            ])
]);
unlink("click/$cid.step");
}
}
if($step == "changeqiwiusdclick1"){
	if($tx > 1){
	$ru = ($tx * 122);
$qu = ($tx * 128);
$zu = ($tx * 8400);
$ur = ($tx / 140);
$uq = ($tx / 140);
$uz = ($tx / 9000);
$up = ($tx / 9000);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$up");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","UZCARD");
put("click/$cid.tmp4","QIWIUSD");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp UZS evaziga $up QIWI USD olasiz.

```8600042384320809```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu 8600042384320809 karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $tmp UZS

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim3'],],
            ]
            ])
]);
unlink("click/$cid.step");
}
}
if($step == "changexbetclick"){
	if($tx > 149){
		$ru = ($tx * 140);
$qu = ($tx * 128);
$zu = ($tx * 8400);
$ur = ($tx / 140);
$uq = ($tx / 140);
$uz = ($tx / 9000);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$ru");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","UZCARD");
put("click/$cid.tmp4","1xBetRUB");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp 1xBet RUB evaziga $ru UZS olasiz.

```8600042384320809```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu 8600042384320809 karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $tmp 1xBet RUB

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim4'],],
            ]
            ])
]);
unlink("click/$cid.step");
}
}
if($step == "changexbetclick1"){
	if($tx > 19999){
$ru = ($tx * 122);
$qu = ($tx * 128);
$zu = ($tx * 8400);
$ur = ($tx / 140);
$uq = ($tx / 140);
$uz = ($tx / 9000);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$ur");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","UZCARD");
put("click/$cid.tmp4","1xBetRUB");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp UZS evaziga $ur RUB olasiz.

```8600042384320809```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu 8600042384320809 karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $tmp UZS

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
 'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim4'],],
            ]
            ])
]);
unlink("click/$cid.step");
}
}
if($step == "changebeelclick"){
	if($tx > 1000){
		$ru = ($tx / 11);
$qu = ($tx * 128);
$zu = ($tx * 8400);
$ur = ($tx / 140);
$uq = ($tx / 140);
$uz = ($tx / 9000);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$ru");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","UZCARD");
put("click/$cid.tmp4","BeelineMB");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp Beeline MB evaziga $ru UZS olasiz.

```+998943060506```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu +998943060506 karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $tmp Beeline MB

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim5'],],
            ]
            ])
]);
unlink("click/$cid.step");
}
}
if($step == "changebeelclick1"){
	if($tx > 19999){
$ru = ($tx * 122);
$qu = ($tx * 128);
$zu = ($tx * 8400);
$ur = ($tx / 11);
$uq = ($tx / 140);
$uz = ($tx / 9000);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$ur");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","UZCARD");
put("click/$cid.tmp4","BeelineMB");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp UZS evaziga $ur Beeline MB olasiz.

```8600042384320809```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu 8600042384320809 karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $tmp UZS

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
 'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim5'],],
            ]
            ])
]);
unlink("click/$cid.step");
}
}
if($step == "changeqiwiclick"){
	if($tx > 149){
		$ru = ($tx * 128);
$qu = ($tx * 128);
$zu = ($tx * 8400);
$ur = ($tx / 140);
$uq = ($tx / 140);
$uz = ($tx / 9000);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$ru");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","UZCARD");
put("click/$cid.tmp4","QIWIRUB");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp QIWI RUB evaziga $ru UZS olasiz.

```+998943060506```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu +998943060506 karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $tmp QIWI RUB

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim1'],],
            ]
            ])
]);
unlink("click/$cid.step");
}
}
if($step == "changeqiwiclick1"){
	if($tx > 19999){
$ru = ($tx * 122);
$qu = ($tx * 128);
$zu = ($tx * 8400);
$ur = ($tx / 128);
$uq = ($tx / 140);
$uz = ($tx / 9000);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$ur");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","UZCARD");
put("click/$cid.tmp4","QIWIRUB");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp UZS evaziga $ur QIWI RUB olasiz.

```8600042384320809```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu 8600042384320809 karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $tmp UZS

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
 'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim1'],],
            ]
            ])
]);
unlink("click/$cid.step");
}
}
if($step == "changewmzuzcard"){
	if($tx > 1){
		$ru = ($tx * 122);
$qu = ($tx * 128);
$zu = ($tx * 8400);
$ur = ($tx / 140);
$uq = ($tx / 140);
$uz = ($tx / 9000);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$zu");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","UZCARD");
put("click/$cid.tmp4","WMZ");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp WMZ evaziga $zu UZS olasiz.

```Z443298083933```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu Z443298083933 karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $tmp WMZ

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim7'],],
            ]
            ])
]);
unlink("click/$cid.step");
}
}
if($step == "changewmzuzcard1"){
	if($tx > 19999){
$ru = ($tx * 122);
$qu = ($tx * 128);
$zu = ($tx * 8400);
$ur = ($tx / 140);
$uq = ($tx / 140);
$uz = ($tx / 8400);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$uz");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","UZCARD");
put("click/$cid.tmp4","WMZ");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp UZS evaziga $uz WMZ olasiz.

```Z443298083933```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu Z443298083933 karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $tmp UZS

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
 'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim7'],],
            ]
            ])
]);
unlink("click/$cid.step");
}
}
if($step == "changeqiwiusduzcard"){
	if($tx > 1){
		$ru = ($tx * 122);
$qu = ($tx * 128);
$zu = ($tx * 8200);
$ur = ($tx / 140);
$uq = ($tx / 140);
$uz = ($tx / 9000);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$zu");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","UZCARD");
put("click/$cid.tmp4","QIWIUSD");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp QIWI USD evaziga $zu UZS olasiz.

```+998943060506```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu +998943060506 karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $tmp QIWI USD

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim3'],],
            ]
            ])
]);
unlink("click/$cid.step");
}
}
if($step == "changeqiwiusduzcard1"){
	if($tx > 19999){
$ru = ($tx * 122);
$qu = ($tx * 128);
$zu = ($tx * 8400);
$ur = ($tx / 140);
$uq = ($tx / 140);
$uz = ($tx / 8200);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$uz");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","UZCARD");
put("click/$cid.tmp4","QIWIUSD");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp UZS evaziga $uz QIWI USD olasiz.

```8600042384320809```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu 8600042384320809 karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $tmp UZS

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
 'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim3'],],
            ]
            ])
]);
unlink("click/$cid.step");
}
}
if($step == "changesberuzcard"){
	if($tx > 2){
		$ru = ($tx * 122);
$qu = ($tx * 128);
$zu = ($tx * 8400);
$ur = ($tx / 140);
$uq = ($tx / 140);
$su = ($tx / 140);
$us = ($tx * 126);
$uz = ($tx / 9000);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$us");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","UZCARD");
put("click/$cid.tmp4","SBERBANKRUB");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp SBERBANK RUB evaziga $us UZS olasiz.

```4817760153462555```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu 4817760153462555 karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $tmp SBERBANK RUB

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim8'],],
            ]
            ])
]);
unlink("click/$cid.step");
}
}
if($step == "changesberuzcard1"){
	if($tx > 19999){
$ru = ($tx * 122);
$qu = ($tx * 128);
$zu = ($tx * 8400);
$ur = ($tx / 140);
$su = ($tx / 126);
$us = ($tx * 126);
$uq = ($tx / 140);
$uz = ($tx / 9000);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$su");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","UZCARD");
put("click/$cid.tmp4","SBERBANKRUB");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp UZS evaziga $su SBERBANK RUB olasiz.

```4817760153462555```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu 4817760153462555 karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $tmp UZS

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim8'],],
            ]
            ])
]);
unlink("click/$cid.step");
}
}
if($step == "changeclicksber"){
	if($tx > 19999){
$ru = ($tx * 122);
$qu = ($tx * 128);
$zu = ($tx * 8400);
$ur = ($tx / 140);
$uq = ($tx / 140);
$su = ($tx / 126);
$us = ($tx * 126);
$uz = ($tx / 9000);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$su");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","SBERBANKRUB");
put("click/$cid.tmp4","UZCARD");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp UZS evaziga $su SBERBANK RUB olasiz.

```8600042384320809```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu -8600042384320809- karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $tmp UZS

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim8'],],
            ]
            ])
]);
unlink("click/$cid.step");
}
}
if($step == "changeclicksber1"){
	if($tx > 149){
$ru = ($tx * 122);
$qu = ($tx * 128);
$zu = ($tx * 8400);
$ur = ($tx / 140);
$su = ($tx / 140);
$us = ($tx * 140);
$uq = ($tx / 140);
$uz = ($tx / 9000);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$us");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","SBERBANKRUB");
put("click/$cid.tmp4","UZCARD");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp SBERBANK RUB uchun $us UZS kiritasiz.

```8600042384320809```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu -8600042384320809- karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $us UZS

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim8'],],
            ]
            ])
]);
unlink("click/$cid.step");
}
}
if($step == "changeclickwmr"){
	if($tx > 149){
$ru = ($tx * 122);
$qu = ($tx * 128);
$zu = ($tx * 8400);
$ur = ($tx / 140);
$uq = ($tx / 140);
$uz = ($tx / 9000);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$ur");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","WMR");
put("click/$cid.tmp4","UZCARD");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp UZS evaziga $ur WMR olishingiz mumkin.

```8600042384320809```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu -8600042384320809- karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $tmp UZS

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim2'],],
            ]
            ])
]);
unlink("click/$cid.step");
}
}
if($step == "changeclickwmr1"){
	if($tx > 149){
$ru = ($tx * 122);
$qu = ($tx * 128);
$zu = ($tx * 8400);
$ur = ($tx / 140);
$uq = ($tx / 140);
$uz = ($tx / 9000);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$qz");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","WMR");
put("click/$cid.tmp4","UZCARD");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp WMR olish uchun $qz UZS kiritasiz.

```8600042384320809```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu -8600042384320809- karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $qz UZS

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim2'],],
			
            ]
            ])
]);
unlink("click/$cid.step");
}
}
if($step == "changeclickwmz"){
	if($tx > 149){
$ru = ($tx * 122);
$qu = ($tx * 128);
$zu = ($tx * 8400);
$ur = ($tx / 140);
$uq = ($tx / 140);
$uz = ($tx / 9000);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$uz");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","WMZ");
put("click/$cid.tmp4","UZCARD");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp UZS evaziga  $uz WMZ olasiz.

```8600042384320809```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu -8600042384320809- karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $tmp UZS

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim7'],],
			
            ]
            ])
]);
unlink("click/$cid.step");
}
}
if($step == "changeclickwmz1"){
	if($tx > 1){
$ru = ($tx * 122);
$qu = ($tx * 128);
$zu = ($tx * 8400);
$ur = ($tx / 140);
$uq = ($tx / 140);
$uz = ($tx * 9000);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$uz");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","WMZ");
put("click/$cid.tmp4","UZCARD");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp WMz olish uchun $uz UZS kiritasiz.

```8600042384320809```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu -8600042384320809- karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $uz UZS

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim7'],],
			
            ]
            ])
]);
unlink("click/$cid.step");
}
}
if($step == "changeclickusd"){
	if($tx > 19999){
$ru = ($tx * 122);
$qu = ($tx * 128);
$zu = ($tx * 8400);
$ur = ($tx / 140);
$uq = ($tx / 140);
$uz = ($tx / 9000);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$ur");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","QIWIUSD");
put("click/$cid.tmp4","UZCARD");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp UZS evaziga $ur QIWI USD olasiz.

```8600042384320809```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu -8600042384320809- karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $tmp UZS

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim3'],],
			
            ]
            ])
]);
unlink("click/$cid.step");
}
}
if($step == "changeclickxbet"){
	if($tx > 19999){
$ru = ($tx * 122);
$qu = ($tx * 128);
$zu = ($tx * 8400);
$ur = ($tx / 140);
$uq = ($tx / 140);
$uz = ($tx / 9000);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$ur");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","1xBetRUB");
put("click/$cid.tmp4","UZCARD");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp UZS evaziga $ur 1xBet RUB olasiz.

```8600042384320809```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu -8600042384320809- karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $tmp UZS

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim4'],],
			
            ]
            ])
]);
unlink("click/$cid.step");
}
}
if($step == "changeclickbeel"){
	if($tx > 19999){
$ru = ($tx * 122);
$qu = ($tx * 128);
$zu = ($tx * 8400);
$ur = ($tx / 140);
$uq = ($tx / 140);
$uz = ($tx / 11000);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$uz");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","BeelineMB");
put("click/$cid.tmp4","UZCARD");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp UZS evaziga $uz Beeline MB olasiz.

```8600042384320809```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu -8600042384320809- karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $tmp UZS

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim5'],],
			
            ]
            ])
]);
unlink("click/$cid.step");
}
}
if($step == "changeclickqiwi"){
	if($tx > 19999){
$ru = ($tx * 122);
$qu = ($tx * 128);
$zu = ($tx * 8400);
$ur = ($tx / 140);
$uq = ($tx / 140);
$uz = ($tx / 9000);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$ur");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","QIWIRUB");
put("click/$cid.tmp4","UZCARD");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp UZS evaziga $ur QIWI olasiz.

```8600042384320809```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu -8600042384320809- karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $tmp UZS

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim1'],],
			
            ]
            ])
]);
unlink("click/$cid.step");
}
}
if($step == "changeclickqiwi1"){
	if($tx > 149){
$ru = ($tx * 122);
$qu = ($tx * 128);
$zu = ($tx * 8400);
$ur = ($tx / 140);
$uq = ($tx / 140);
$uz = ($tx / 9000);
$qz = ($tx * 140);
$name = $message->from->first_name;
put("click/$cid.ism","$name");
put("click/$cid.miq","$qz");
put("click/$cid.tmp","$tx");
put("click/$cid.tmp2","$tx");
put("click/$cid.tmp3","QIWIRUB");
put("click/$cid.tmp4","UZCARD");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Siz $tmp RUB olish uchun $qz UZS kiritasiz.

```8600042384320809```

👆Ko'chirib olish uchun

Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:

► Payme.uz , Mbank.uz , Upay.uz , Uzcard.uz - to'lov tizimlarining hohlaganiga kiring;
►Pastroqda ko'rsatilgan pul mablag'ini shu -8600042384320809- karta raqamiga o'tkazing;
►«To'lov qildim» tugmasini bosing;
►Operator tomonidan almashuv tasdiqlanishini kuting.

Miqdor: $qz UZS

Ushbu tekshiruv operator tomonidan amalga oshiriladi va ish vaqtida o'rtacha 2 dan 10 daqiqagacha davom etadi 

 E'tibor bering! Boshqa to'lov tizimlaridan (CLICK va OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin ",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'To`lov qildim','callback_data'=>'toladim1'],],
			
            ]
            ])
]);
unlink("click/$cid.step");
}
}
 /* 
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Nimani almashtirmoqchisiz?",
'parse_mode'=>"markdown",
 'reply_markup'=>json_encode(
['resize_keyboard'=>true,
'inline_keyboard' => [
[["text"=>"Wmr","callback_data" =>"1"],["text"=>"UzCard","callback_data" =>"2"],],
]
])
			
]);
}
if ($call == '1') {
    bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'text'=>"Tanlang",
        'reply_markup'=>json_encode(
['resize_keyboard'=>true,
'inline_keyboard' => [
[["text"=>"Wmr","callback_data" =>"1"],["text"=>"UzCard","callback_data" =>"2"],],
]
])
        ]);

}
*/
if($tx == "+ Wmrni") {
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Wmrni Nimaga almashtirmoqchisiz?",
'parse_mode'=>"markdown",
'reply_markup'=>$nimaga,
]);
}
if($tx == "UzCardga") {
put("click/$cid.step","change");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Qancha wmr almashtirasiz?",
'parse_mode'=>"markdown",
]);
}

if($step == "change"){
if($tx == "🏠 Bosh menu"){
}else{
if($tx <= 300 and $tx >= 40){
put("click/$cid.tmp","$tx");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"*рџ’іClick raqamingizni kiriting*",
'parse_mode'=>"markdown",
'reply_markup'=>$bekor,
]);
put("click/$cid.step","click");
}else{
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"Sizga kerakli pul miqdorni RUBda kiriting
*Kamida: 40 RUB
Ko'pi bilan: 300 RUB*",
'parse_mode'=>"markdown",
'reply_markup'=>$bekor,
]);
}
}
}

if($step == "click"){
if($tx == "🏠 Bosh menu"){
}else{
$str = strlen($tx);
$str1 = strlen("8600050486838883");
if($str == $str1){
put("click/$cid.tmp2","$tx");
$tmp = file_get_contents("click/$cid.tmp");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"*вњ…Click raqami qabul qilindi.*
Endi `+998943060506` shu qiwi raqamiga *$tmp* RUB pulni o'tkazing va tekshirish tugmasini bosing
вќпёЏAgarda pulni o'tkazmasdan tekshirishni bossangiz *ban* beriladi.",
'parse_mode'=>"markdown",
'reply_markup'=>$but,
]);
unlink("click/$cid.step");
}else{
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"*рџ’іClick raqamingizni orasida uzulishlarsiz kiriting*",
'parse_mode'=>"markdown",
'reply_markup'=>$bekor,
]);
}
}
}



if($tx == "🏠 Bosh menu"){
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"*Bosh Menu*",
'parse_mode'=>"markdown",
'reply_markup'=>$buton,
]);
unlink("click/$cid.step");
unlink("click/$cid.tmp");
unlink("click/$cid.tmp2");
}

if($tx == "🕰 Ish vaqti"){
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"🕰 Ish vaqti:

*08:00 dan 23:00 gacha*",
'parse_mode'=>"markdown",
'reply_markup'=>$buton,
]);
}

if($tx == "📊Kurs | 💰Zahira"){

bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"📉 Sotish kursi
1 QIWI RUB = 140 UZS
1 QIWI USD = 9000 UZS
1 WMZ = 9000 UZS
1 WMR = 140 UZS
1 1xbet RUB = 140 UZS
Beeline 1000 MB = 11000 UZS
1 Сбербанк RUB = 140 UZS

📉 Olish kursi
1 QIWI RUB = 128 UZS
1 QIWI USD = 8200 UZS
1 WMZ = 8400 UZS
1 WMR = 122 UZS
1 Сбербанк RUB = 126 UZS",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'💰 Zahirani ko`rish','callback_data'=>'zahira'],],
         ]
		 ])
]);
}

if ($call == 'zahira') {
	 bot('editMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$message_id,
		'parse_mode'=>"markdown",
		'reply_to_message_id'=>$miid,
		'text'=>"*Obmennik zahirasi*
UZCARD UZS = `$uzcardzahira` UZS
WMR = `$wmrzahira` WMR
WMZ = `$wmzzahira` USD
QIWI RUB = `$qiwizahira` RUB
QIWI USD = `$qiwiusdzahira` USD
1xBet RUB = `$xbetrubzahira` RUB
Beeline MB = `$beelinembzahira` MB
Сбербанк RUB = `$sberzahira` RUB
		",
		 ]);
}

if($tx == "📞 Biz bilan aloqa"){
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"👨🏼‍✈️ Qo'llab-quvvatlash: @myobmeuz",
'parse_mode'=>"markdown",
'reply_markup'=>$buton,
]);
}

if((mb_stripos($tx,"/no")!==false) and $cid == $admin){
$ex = explode("_",$tx);
$idi = $ex[1];
$sum = $ex[2];
$ol = $ex[3];
$ber = $ex[4];
$res = bot('sendmessage',[
'chat_id'=>$idi,
'text'=>"Sizning buyurtmangiz bajarilmadi. Sababi to'lov amalga oshirilmagan.",
]);
if($res->ok){
bot('sendmessage',[
'chat_id'=>"@myobmenchek",
'text'=>"Bajarilmadi!
рџ‘¤Id: $idi
рџ’ё: $sum RUB",
]);
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"Yuborildi!",
]);
}else{
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"Yuborilmadi!",
]);
}
}

if((mb_stripos($tx,"/ok")!==false) and $cid == $admin){
$ex = explode("_",$tx);
$sum = $ex[2];
$idi = $ex[1];
$ol = $ex[3];
$ber = $ex[4];
$aq = $ex[5];
$uz = strtolower($ol);
$zu = strtolower($ber);
$ism = file_get_contents("click/$cid.ism");
$bugun = date('d.m.Y',strtotime('5 hour'));
$soat = date('H:i', strtotime('5 hour'));
if (($uz) == "WMR"){
$new = $wmrzahira + $aq;
} elseif (($uz) == "UZCARD"){
$new = $uzcardzahira + $aq;
} elseif (($uz) == "QIWIRUB"){
$new = $qiwizahira + $aq;
} elseif (($uz) == "QIWIUSD"){
$new = $qiwiusdzahira + $aq;
} elseif (($uz) == "1XBETRUB"){
$new = $xbetrubzahira + $aq;
} elseif (($uz) == "BEELINEMB"){
$new = $beelinembzahira + $aq;
} elseif (($uz) == "SBERBANKRUB"){
$new = $sberzahira + $aq;
} elseif (($uz) == "WMZ"){
	$new = $wmzzahira + $aq;
}
if (($zu) == "WMR"){
$new1 = $wmrzahira - $sum;
} elseif (($zu) == "UZCARD"){
$new1 = $uzcardzahira - $sum;
} elseif (($zu) == "QIWIRUB"){
$new1 = $qiwizahira - $sum;
} elseif (($zu) == "SBERBANK"){
$new1 = $sberzahira - $sum;
} elseif (($zu) == "WMZ"){
	$new1 = $wmzzahira - $sum;
}
put ("zahira/$uz.txt","$new");
put ("zahira/$zu.txt","$new1");
$res = bot('sendmessage',[
'chat_id'=>$idi,
'text'=>"Buyurtma bajarildi
Barcha buyurtma almashuvlarini @myobmenchek kanalida ko`rishingiz mumkin",
]);
bot('sendmessage',[
'chat_id'=>"@myobmenchek",
'text'=>"ID: $idi\n👤: $ism\n🔀: $uz ⏩ $zu\n📆: $bugun $soat\n🔎Holat: ✅\n💰: $aq $zu",
]);

if($res->ok){
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"Yuborildi!",
]);
}else{
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"Yuborilmadi!",
]);
}
}

if((mb_stripos($tx,"/ban")!==false) and $cid == $admin){
$ex = explode("_",$tx);
$sum = $ex[2];
$idi = $ex[1];
$baza = get("click.ban");
put("click.ban", "$baza\n$idi");
$res = bot('sendmessage',[
'chat_id'=>$idi,
'text'=>"*BAN bilan tabriklayman, endi siz bandan chiqmaysiz!*",
'parse_mode'=>"markdown",
]);
if($res->ok){
bot('sendmessage',[
'chat_id'=>"@testuchund",
'text'=>"BAN!\nID: $idi",
]);
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"Yuborildi!",
]);
}else{
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"Yuborilmadi!",
]);
}
}

if($tx == "/stat"){
$baza = get("click.dat");
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"$baza",
]);
}
}

?>