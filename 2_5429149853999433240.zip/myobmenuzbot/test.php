<?php
$servername = 'localhost';
$username = 'islom2727_obmen';
$database = 'islom2727_obmen';
$password = '3060506a';
$conn = new mysqli($servername, $username, $password, $database);

$query = "SELECT * FROM 'eb_users'";
$result = $conn->query($query);

echo $result;
?>