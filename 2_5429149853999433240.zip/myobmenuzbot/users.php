<?php
/** модель работы с пользователями **/

function make_user($first_name,$cid){
	global $db;
	$name = mysql_real_escape_string($first_name);
	$chat_id = mysql_real_escape_string($cid);
	$query = "insert into `users`(name,chat_id) values('{$name}','{$chat_id}')";
	mysql_query($query,$db) or die("пользователя создать не удалось");
}

function is_user_set($first_name){
	global $db;
	$name = mysql_real_escape_string($first_name);
	$result = mysql_query("select * from `users` where name='$name' LIMIT 1",$conn);

    if(mysql_fetch_array($result) !== false) return true;
    return false;
}

// задание настройки
function set_udata($first_name,$data = array()){
	global $db;
	$name = mysql_real_escape_string($first_name);
	if(!is_user_set($name)){
		make_user($name,0); // если каким-то чудом этот пользователь не зарегистрирован в базе
	}
	$data = json_encode($data,JSON_UNESCAPED_UNICODE);
	mysql_query("update `users` SET data_json = '{$data}' WHERE name = '{$name}'",$conn); // обновляем запись в базе
}

// считываение настройки
function get_udata($first_name){
	global $db;
	$res = array();
	$name = mysql_real_escape_string($first_name);
	$result = mysql_query("select * from `users` where name='$name'",$conn);
	$arr = mysql_fetch_assoc($result);
    if(isset($arr['data_json'])){
		$res = json_decode($arr['data_json'], true);
	}
	
	return $res;
}